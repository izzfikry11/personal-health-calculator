/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/WebServices/WebService.java to edit this template
 */
package org.bmrCalc;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author limxi
 */
@WebService(serviceName = "BmrCalc")
public class BmrCalc {

@WebMethod(operationName = "calculateBMR")
public String calculateBMR(@WebParam(name = "weight_kg") double weight, 
                          @WebParam(name = "height_cm") double height,
                          @WebParam(name = "gender_male_or_female") String gender, 
                          @WebParam(name = "age_years") int age) 
{   
    double bmr = 0;
    
    if ("male".equalsIgnoreCase(gender)) {
        bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
        return "Your BMR is "+ bmr + " colories/day";

    } else if ("female".equalsIgnoreCase(gender)) {
        bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
        return "Your BMR is "+ bmr + " colories/day";

    } else {
}       return "Wrong input for Gender!! Please enter 'Male' or 'Female'.";

}

    
}
